import { Routes, Route } from "react-router-dom";

import Navbar from "./components/Navbar";
import Home from "./components/Home";
import StudentList from "./components/StudentList";
import StudentDetails from "./components/StudentDetails";
import CourseList from "./components/CourseList";
import CourseDetails from "./components/CourseDetails";
import About from "./components/About";
import NotFound from "./components/NotFound";

function App() {
  return (
    <>
      <Navbar />

      <main className="main-content">
        <Routes>
          <Route path="/" element={<Home />} />

          <Route path="/students" element={<StudentList />} />

          <Route path="/students/:id" element={<StudentDetails />} />

          <Route path="/courses" element={<CourseList />} />

          <Route path="/courses/:id" element={<CourseDetails />} />

          <Route path="/about" element={<About />} />

          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>

      <footer>
        <p>© 2026 College Student Management Portal</p>
      </footer>
    </>
  );
}

export default App;