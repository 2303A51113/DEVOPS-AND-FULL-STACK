import { useNavigate, useParams } from "react-router-dom";

const courses = {
  1: {
    name: "Computer Science & Engineering",
    code: "CSE",
    duration: "4 Years",
    description:
      "A comprehensive program covering programming, algorithms, databases, operating systems and software development.",
  },

  2: {
    name: "Electronics & Communication",
    code: "ECE",
    duration: "4 Years",
    description:
      "A program focusing on electronics, communication systems, embedded systems and digital technologies.",
  },

  3: {
    name: "Information Technology",
    code: "IT",
    duration: "4 Years",
    description:
      "A technology-focused program covering software engineering, networking, cloud computing and information systems.",
  },

  4: {
    name: "Artificial Intelligence",
    code: "AI",
    duration: "4 Years",
    description:
      "A modern program focusing on machine learning, deep learning, artificial intelligence and data science.",
  },
};

function CourseDetails() {
  const { id } = useParams();
  const navigate = useNavigate();

  const course = courses[id];

  if (!course) {
    return (
      <div className="error-container">
        <h1>Course Not Found</h1>

        <button
          className="primary-btn"
          onClick={() => navigate("/courses")}
        >
          ← Back to Courses
        </button>
      </div>
    );
  }

  return (
    <section className="details-container">
      <button
        className="back-btn"
        onClick={() => navigate(-1)}
      >
        ← Go Back
      </button>

      <div className="course-detail-card">
        <p className="section-label">COURSE INFORMATION</p>

        <h1>{course.name}</h1>

        <div className="course-detail-grid">
          <div>
            <span>Course Code</span>
            <strong>{course.code}</strong>
          </div>

          <div>
            <span>Duration</span>
            <strong>{course.duration}</strong>
          </div>
        </div>

        <p className="course-description">
          {course.description}
        </p>
      </div>
    </section>
  );
}

export default CourseDetails;