import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const students = {
  101: {
    id: 101,
    name: "Rahul",
    branch: "CSE",
    year: "III",
    email: "rahul@college.edu",
    phone: "9876543210",
  },

  102: {
    id: 102,
    name: "Priya",
    branch: "ECE",
    year: "III",
    email: "priya@college.edu",
    phone: "9876543211",
  },

  103: {
    id: 103,
    name: "Arjun",
    branch: "IT",
    year: "II",
    email: "arjun@college.edu",
    phone: "9876543212",
  },

  104: {
    id: 104,
    name: "Sneha",
    branch: "CSE",
    year: "IV",
    email: "sneha@college.edu",
    phone: "9876543213",
  },
};

function StudentDetails() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [student, setStudent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    console.log("StudentDetails Component Mounted");

    return () => {
      console.log("StudentDetails Component Unmounted");
    };
  }, []);

  useEffect(() => {
    console.log("Selected student changed:", id);

    setLoading(true);
    setError("");
    setStudent(null);

    const timer = setTimeout(() => {
      const selectedStudent = students[id];

      if (selectedStudent) {
        setStudent(selectedStudent);
      } else {
        setError("Student does not exist.");
      }

      setLoading(false);
    }, 700);

    return () => {
      clearTimeout(timer);
      console.log("Previous student data request cleaned up");
    };
  }, [id]);

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loader"></div>
        <h2>Loading student information...</h2>
      </div>
    );
  }

  if (error) {
    return (
      <div className="error-container">
        <div className="error-icon">⚠️</div>
        <h1>Student Not Found</h1>
        <p>{error}</p>

        <button
          className="primary-btn"
          onClick={() => navigate("/students")}
        >
          ← Back to Students
        </button>
      </div>
    );
  }

  return (
    <section className="details-container">
      <button
        className="back-btn"
        onClick={() => navigate(-1)}
      >
        ← Go Back
      </button>

      <div className="details-card">
        <div className="details-top">
          <div className="large-avatar">
            {student.name.charAt(0)}
          </div>

          <div>
            <p className="section-label">STUDENT PROFILE</p>
            <h1>{student.name}</h1>
            <p>Student ID: {student.id}</p>
          </div>
        </div>

        <div className="details-grid">
          <div className="detail-item">
            <span>Student ID</span>
            <strong>{student.id}</strong>
          </div>

          <div className="detail-item">
            <span>Name</span>
            <strong>{student.name}</strong>
          </div>

          <div className="detail-item">
            <span>Branch</span>
            <strong>{student.branch}</strong>
          </div>

          <div className="detail-item">
            <span>Year</span>
            <strong>{student.year}</strong>
          </div>

          <div className="detail-item">
            <span>Email</span>
            <strong>{student.email}</strong>
          </div>

          <div className="detail-item">
            <span>Phone</span>
            <strong>{student.phone}</strong>
          </div>
        </div>

        <div className="lifecycle-box">
          <h3>⚛ React Lifecycle</h3>
          <p>
            Student information is loaded when the component mounts
            and updated whenever the student ID changes.
          </p>
        </div>
      </div>
    </section>
  );
}

export default StudentDetails;