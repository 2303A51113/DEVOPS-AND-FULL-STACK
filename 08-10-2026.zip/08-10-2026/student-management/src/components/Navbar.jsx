import { NavLink } from "react-router-dom";

function HomeIcon() {
  return (
    <svg viewBox="0 0 24 24" className="nav-icon">
      <path d="M3 10.5 12 3l9 7.5" />
      <path d="M5.5 9.5V21h13V9.5" />
      <path d="M9.5 21v-6h5v6" />
    </svg>
  );
}

function StudentIcon() {
  return (
    <svg viewBox="0 0 24 24" className="nav-icon">
      <circle cx="9" cy="7" r="4" />
      <path d="M2 21v-2a7 7 0 0 1 14 0v2" />
      <path d="M16 4.5a4 4 0 0 1 0 7.5" />
      <path d="M19 14a5 5 0 0 1 3 4.5V21" />
    </svg>
  );
}

function CourseIcon() {
  return (
    <svg viewBox="0 0 24 24" className="nav-icon">
      <path d="m3 6 9-3 9 3-9 3-9-3Z" />
      <path d="M6 8v5c0 2 2.7 4 6 4s6-2 6-4V8" />
      <path d="M21 7v7" />
    </svg>
  );
}

function AboutIcon() {
  return (
    <svg viewBox="0 0 24 24" className="nav-icon">
      <circle cx="12" cy="12" r="9" />
      <path d="M12 11v5" />
      <path d="M12 8h.01" />
    </svg>
  );
}

function Navbar() {
  const navItems = [
    { to: "/", label: "Dashboard", icon: <HomeIcon />, end: true },
    { to: "/students", label: "Students", icon: <StudentIcon /> },
    { to: "/courses", label: "Courses", icon: <CourseIcon /> },
    { to: "/about", label: "About", icon: <AboutIcon /> },
  ];

  return (
    <aside className="navbar">
      <div className="brand">
        <div className="brand-logo">CS</div>

        <div className="brand-text">
          <h2>Campus</h2>
          <span>Student Portal</span>
        </div>
      </div>

      <div className="nav-section">
        <p className="nav-heading">MAIN MENU</p>

        <div className="nav-links">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                isActive ? "nav-link active" : "nav-link"
              }
            >
              {item.icon}
              <span>{item.label}</span>
            </NavLink>
          ))}
        </div>
      </div>

      <div className="sidebar-bottom">
        <div className="college-mini-card">
          <div className="mini-icon">C</div>
          <div>
            <strong>College Portal</strong>
            <span>2026–27</span>
          </div>
        </div>
      </div>
    </aside>
  );
}

export default Navbar;