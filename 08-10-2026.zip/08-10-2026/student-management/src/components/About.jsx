function About() {
  return (
    <section className="page-container">
      <div className="about-card">
        <p className="section-label">ABOUT THE APPLICATION</p>

        <h1>College Student Management Portal</h1>

        <p>
          This React application provides a simple and efficient
          interface for managing college student information and
          academic courses.
        </p>

        <div className="about-grid">
          <div>
            <h3>⚛ React</h3>
            <p>Component-based frontend development.</p>
          </div>

          <div>
            <h3>🔀 React Router</h3>
            <p>Client-side navigation without page reloads.</p>
          </div>

          <div>
            <h3>🔄 Lifecycle</h3>
            <p>useEffect handles mount, update and cleanup operations.</p>
          </div>

          <div>
            <h3>📱 Responsive</h3>
            <p>Designed to work across different screen sizes.</p>
          </div>
        </div>
      </div>
    </section>
  );
}

export default About;