import { Link } from "react-router-dom";

const courses = [
  {
    id: 1,
    name: "Computer Science & Engineering",
    code: "CSE",
    duration: "4 Years",
    icon: "💻",
  },
  {
    id: 2,
    name: "Electronics & Communication",
    code: "ECE",
    duration: "4 Years",
    icon: "📡",
  },
  {
    id: 3,
    name: "Information Technology",
    code: "IT",
    duration: "4 Years",
    icon: "🌐",
  },
  {
    id: 4,
    name: "Artificial Intelligence",
    code: "AI",
    duration: "4 Years",
    icon: "🤖",
  },
];

function CourseList() {
  return (
    <section className="page-container">
      <div className="page-header">
        <div>
          <p className="section-label">ACADEMIC PROGRAMS</p>
          <h1>Courses</h1>
          <p>Explore the programs offered by our college.</p>
        </div>
      </div>

      <div className="course-grid">
        {courses.map((course) => (
          <div className="course-card" key={course.id}>
            <div className="course-icon">{course.icon}</div>

            <p className="course-code">{course.code}</p>

            <h2>{course.name}</h2>

            <p>Duration: {course.duration}</p>

            <Link
              to={`/courses/${course.id}`}
              className="details-btn"
            >
              Course Details →
            </Link>
          </div>
        ))}
      </div>
    </section>
  );
}

export default CourseList;