import { Link } from "react-router-dom";

function Home() {
  return (
    <section className="dashboard-page">

      {/* Welcome Banner */}
      <div className="welcome-banner">
        <div className="welcome-content">
          <span className="welcome-badge">COLLEGE MANAGEMENT SYSTEM</span>

          <h1>
            Welcome to your
            <span> Student Portal</span>
          </h1>

          <p>
            Manage student information, explore academic programs,
            and navigate through the college management system.
          </p>

          <div className="hero-buttons">
            <Link to="/students" className="primary-btn">
              View Students →
            </Link>

            <Link to="/courses" className="secondary-btn">
              Explore Courses
            </Link>
          </div>
        </div>

        <div className="welcome-illustration">
          <div className="illustration-circle">
            🎓
          </div>

          <div className="floating-card floating-one">
            <strong>4</strong>
            <span>Students</span>
          </div>

          <div className="floating-card floating-two">
            <strong>4</strong>
            <span>Courses</span>
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="stats-grid">

        <div className="stat-card">
          <div className="stat-icon students-stat">S</div>
          <div>
            <span>Total Students</span>
            <h2>4</h2>
            <small>Registered students</small>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon courses-stat">C</div>
          <div>
            <span>Total Courses</span>
            <h2>4</h2>
            <small>Academic programs</small>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon department-stat">D</div>
          <div>
            <span>Departments</span>
            <h2>3</h2>
            <small>Active departments</small>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon year-stat">Y</div>
          <div>
            <span>Academic Year</span>
            <h2>2026</h2>
            <small>Current academic year</small>
          </div>
        </div>

      </div>

      {/* Quick Actions */}
      <div className="section-title">
        <div>
          <span>QUICK ACCESS</span>
          <h2>Explore the Portal</h2>
        </div>
      </div>

      <div className="quick-grid">

        <Link to="/students" className="quick-card">
          <div className="quick-icon">👨‍🎓</div>

          <div>
            <h3>Student Directory</h3>
            <p>
              Browse registered students and view their profiles.
            </p>
          </div>

          <span className="arrow">→</span>
        </Link>

        <Link to="/courses" className="quick-card">
          <div className="quick-icon">📚</div>

          <div>
            <h3>Academic Courses</h3>
            <p>
              Explore available academic programs and course details.
            </p>
          </div>

          <span className="arrow">→</span>
        </Link>

        <Link to="/about" className="quick-card">
          <div className="quick-icon">ℹ️</div>

          <div>
            <h3>About Portal</h3>
            <p>
              Learn about the technologies used in this application.
            </p>
          </div>

          <span className="arrow">→</span>
        </Link>

      </div>

    </section>
  );
}

export default Home;