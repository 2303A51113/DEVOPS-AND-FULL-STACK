import { useState } from "react";
import { Link } from "react-router-dom";

const students = [
  {
    id: 101,
    name: "Rahul",
    branch: "CSE",
    year: "III",
    email: "rahul@college.edu",
  },
  {
    id: 102,
    name: "Priya",
    branch: "ECE",
    year: "III",
    email: "priya@college.edu",
  },
  {
    id: 103,
    name: "Arjun",
    branch: "IT",
    year: "II",
    email: "arjun@college.edu",
  },
  {
    id: 104,
    name: "Sneha",
    branch: "CSE",
    year: "IV",
    email: "sneha@college.edu",
  },
];

function StudentList() {
  const [search, setSearch] = useState("");

  const filteredStudents = students.filter(
    (student) =>
      student.name.toLowerCase().includes(search.toLowerCase()) ||
      student.branch.toLowerCase().includes(search.toLowerCase()) ||
      student.id.toString().includes(search)
  );

  return (
    <section className="page-container">
      <div className="page-header">
        <div>
          <p className="section-label">STUDENT DIRECTORY</p>
          <h1>Students</h1>
          <p>Browse and manage registered college students.</p>
        </div>

        <div className="student-count">
          {filteredStudents.length} Students
        </div>
      </div>

      <div className="search-box">
        🔍
        <input
          type="text"
          placeholder="Search by name, ID or branch..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {filteredStudents.length === 0 ? (
        <div className="empty-state">
          <h2>No students found</h2>
          <p>Try searching with another name, ID or branch.</p>
        </div>
      ) : (
        <div className="student-grid">
          {filteredStudents.map((student) => (
            <div className="student-card" key={student.id}>
              <div className="student-avatar">
                {student.name.charAt(0)}
              </div>

              <div className="student-info">
                <h2>{student.name}</h2>

                <p>
                  <strong>ID:</strong> {student.id}
                </p>

                <p>
                  <strong>Branch:</strong> {student.branch}
                </p>

                <p>
                  <strong>Year:</strong> {student.year}
                </p>

                <Link
                  to={`/students/${student.id}`}
                  className="details-btn"
                >
                  View Details →
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

export default StudentList;