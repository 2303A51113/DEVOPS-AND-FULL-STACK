import StudentCard from "./StudentCard.jsx";

export default function StudentList({ students, onView, onEdit, onDelete }) {
  if (students.length === 0) {
    return <div className="empty-state"><div className="empty-icon">⌕</div><h3>No students found</h3><p>Try changing your search or add a student.</p></div>;
  }

  return (
    <div className="table-wrap">
      <table>
        <thead><tr><th>Roll number</th><th>Student name</th><th>Branch</th><th>Actions</th></tr></thead>
        <tbody>
          {students.map((student) => (
            <StudentCard key={student.id} student={student} onView={onView} onEdit={onEdit} onDelete={onDelete} />
          ))}
        </tbody>
      </table>
    </div>
  );
}
