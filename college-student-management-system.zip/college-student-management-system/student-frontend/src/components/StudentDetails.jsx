export default function StudentDetails({ student, onClose }) {
  if (!student) {
    return <section className="details-card muted-details"><p className="eyebrow">STUDENT DETAILS</p><h2>Choose a student</h2><p>Select View in the table to see the complete student record here.</p></section>;
  }
  return (
    <section className="details-card">
      <div className="details-top"><p className="eyebrow">STUDENT DETAILS</p><button className="close-button" onClick={onClose} aria-label="Close details">×</button></div>
      <div className="avatar">{student.name.trim().split(/\s+/).map((part) => part[0]).join("").slice(0, 2).toUpperCase()}</div>
      <h2>{student.name}</h2><p className="detail-subtitle">Student record #{student.id}</p>
      <div className="detail-row"><span>Roll number</span><strong>{student.rollNo}</strong></div>
      <div className="detail-row"><span>Branch</span><strong>{student.branch}</strong></div>
      <div className="detail-row"><span>Student ID</span><strong>{student.id}</strong></div>
    </section>
  );
}
