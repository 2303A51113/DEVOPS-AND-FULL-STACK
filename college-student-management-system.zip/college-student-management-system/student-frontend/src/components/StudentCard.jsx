export default function StudentCard({ student, onView, onEdit, onDelete }) {
  return (
    <tr>
      <td><span className="roll-pill">{student.rollNo}</span></td>
      <td>
        <button className="student-name" onClick={() => onView(student)}>{student.name}</button>
      </td>
      <td><span className="branch-pill">{student.branch}</span></td>
      <td className="actions">
        <button className="icon-button" onClick={() => onView(student)} title="View details">View</button>
        <button className="icon-button" onClick={() => onEdit(student)} title="Edit student">Edit</button>
        <button className="icon-button danger-text" onClick={() => onDelete(student)} title="Delete student">Delete</button>
      </td>
    </tr>
  );
}
