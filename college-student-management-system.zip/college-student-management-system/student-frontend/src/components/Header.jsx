export default function Header() {
  return (
    <header className="topbar">
      <div className="brand-mark" aria-hidden="true">CS</div>
      <div>
        <p className="eyebrow">COLLEGE PORTAL</p>
        <h1>Student Management System</h1>
      </div>
      <span className="api-status"><span className="status-dot" /> REST API</span>
    </header>
  );
}
