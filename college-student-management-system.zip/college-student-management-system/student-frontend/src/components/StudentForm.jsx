import { useEffect, useState } from "react";

const blankForm = { name: "", rollNo: "", branch: "CSE" };

export default function StudentForm({ editingStudent, onSubmit, onCancel }) {
  const [form, setForm] = useState(blankForm);

  useEffect(() => {
    setForm(editingStudent
      ? { name: editingStudent.name, rollNo: editingStudent.rollNo, branch: editingStudent.branch }
      : blankForm);
  }, [editingStudent]);

  function update(event) {
    setForm({ ...form, [event.target.name]: event.target.value });
  }

  function submit(event) {
    event.preventDefault();
    onSubmit(form);
    if (!editingStudent) setForm(blankForm);
  }

  return (
    <form className="student-form" onSubmit={submit}>
      <div className="form-heading">
        <div><p className="eyebrow">{editingStudent ? "UPDATE RECORD" : "NEW RECORD"}</p>
          <h2>{editingStudent ? "Edit student" : "Add a student"}</h2></div>
        {editingStudent && <button type="button" className="text-button" onClick={onCancel}>Cancel edit</button>}
      </div>
      <label>Student name
        <input name="name" value={form.name} onChange={update} placeholder="e.g. Ananya Sharma" required maxLength="80" />
      </label>
      <label>Roll number
        <input name="rollNo" value={form.rollNo} onChange={update} placeholder="e.g. CSE103" required maxLength="20" />
      </label>
      <label>Branch
        <select name="branch" value={form.branch} onChange={update}>
          <option value="CSE">CSE</option><option value="ECE">ECE</option><option value="EEE">EEE</option>
          <option value="MECH">MECH</option><option value="CIVIL">CIVIL</option><option value="IT">IT</option>
          <option value="AI&DS">AI&amp;DS</option><option value="OTHER">Other</option>
        </select>
      </label>
      <button className="primary-button full-button" type="submit">{editingStudent ? "Save changes" : "+ Add student"}</button>
    </form>
  );
}
