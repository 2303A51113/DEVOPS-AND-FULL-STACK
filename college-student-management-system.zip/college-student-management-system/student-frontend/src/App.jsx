import { useCallback, useEffect, useMemo, useState } from "react";
import Header from "./components/Header.jsx";
import StudentList from "./components/StudentList.jsx";
import StudentForm from "./components/StudentForm.jsx";
import StudentDetails from "./components/StudentDetails.jsx";

const API_URL = "http://localhost:5000/api/students";

async function readResponse(response) {
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || `Request failed (${response.status})`);
  return data;
}

export default function App() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [search, setSearch] = useState("");
  const [branchFilter, setBranchFilter] = useState("ALL");
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [editingStudent, setEditingStudent] = useState(null);

  const loadStudents = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch(API_URL);
      const data = await readResponse(response);
      setStudents(data);
      setSelectedStudent((current) => current ? (data.find((s) => s.id === current.id) || null) : null);
      setEditingStudent((current) => current ? (data.find((s) => s.id === current.id) || null) : null);
    } catch (err) {
      setError(`${err.message}. Make sure the backend is running on port 5000.`);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadStudents(); }, [loadStudents]);

  const branches = useMemo(() => [...new Set(students.map((s) => s.branch))].sort(), [students]);
  const visibleStudents = useMemo(() => students.filter((student) => {
    const query = search.trim().toLowerCase();
    const matchesSearch = student.name.toLowerCase().includes(query) || student.rollNo.toLowerCase().includes(query);
    return matchesSearch && (branchFilter === "ALL" || student.branch === branchFilter);
  }), [students, search, branchFilter]);

  async function saveStudent(form) {
    setError(""); setNotice("");
    const isEditing = Boolean(editingStudent);
    const url = isEditing ? `${API_URL}/${editingStudent.id}` : API_URL;
    try {
      const response = await fetch(url, {
        method: isEditing ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const saved = await readResponse(response);
      await loadStudents();
      setSelectedStudent(saved);
      setEditingStudent(null);
      setNotice(isEditing ? "Student updated successfully." : "Student added successfully.");
    } catch (err) {
      setError(err.message || "Could not save student.");
    }
  }

  async function deleteStudent(student) {
    if (!window.confirm(`Delete ${student.name} (${student.rollNo})? This cannot be undone.`)) return;
    setError(""); setNotice("");
    try {
      const response = await fetch(`${API_URL}/${student.id}`, { method: "DELETE" });
      await readResponse(response);
      setStudents((current) => current.filter((item) => item.id !== student.id));
      setSelectedStudent((current) => current?.id === student.id ? null : current);
      setEditingStudent((current) => current?.id === student.id ? null : current);
      setNotice(`${student.name} was deleted.`);
    } catch (err) {
      setError(err.message || "Could not delete student.");
    }
  }

  return (
    <div className="app-shell">
      <Header />
      <main className="page-content">
        <section className="welcome-row">
          <div><p className="eyebrow">OVERVIEW</p><h2>Student dashboard</h2><p className="subtitle">Manage student records in one place.</p></div>
          <button className="refresh-button" onClick={loadStudents} disabled={loading}>↻ Refresh data</button>
        </section>

        <section className="stats-grid">
          <div className="stat-card"><span className="stat-icon purple">♙</span><div><p>Total students</p><strong>{students.length}</strong></div></div>
          <div className="stat-card"><span className="stat-icon blue">▤</span><div><p>Branches represented</p><strong>{branches.length}</strong></div></div>
          <div className="stat-card"><span className="stat-icon green">✓</span><div><p>API connection</p><strong className="connected-text">{error ? "Check API" : loading ? "Loading…" : "Connected"}</strong></div></div>
        </section>

        {error && <div className="alert error-alert" role="alert"><strong>Something went wrong</strong><span>{error}</span><button onClick={() => setError("")} aria-label="Dismiss error">×</button></div>}
        {notice && <div className="alert success-alert" role="status"><span>✓</span><span>{notice}</span><button onClick={() => setNotice("")} aria-label="Dismiss message">×</button></div>}

        <div className="content-grid">
          <section className="panel records-panel">
            <div className="panel-heading"><div><p className="eyebrow">DIRECTORY</p><h2>Student records <span className="count-badge">{visibleStudents.length}</span></h2></div></div>
            <div className="filters">
              <div className="search-box"><span>⌕</span><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search name or roll number…" aria-label="Search students" /></div>
              <select value={branchFilter} onChange={(e) => setBranchFilter(e.target.value)} aria-label="Filter by branch">
                <option value="ALL">All branches</option>{branches.map((branch) => <option key={branch} value={branch}>{branch}</option>)}
              </select>
            </div>
            {loading ? <div className="loading-state"><span className="spinner" /> Loading student records…</div>
              : <StudentList students={visibleStudents} onView={setSelectedStudent} onEdit={setEditingStudent} onDelete={deleteStudent} />}
            <p className="table-footer">Showing {visibleStudents.length} of {students.length} students</p>
          </section>

          <aside className="side-column">
            <StudentForm editingStudent={editingStudent} onSubmit={saveStudent} onCancel={() => setEditingStudent(null)} />
            <StudentDetails student={selectedStudent} onClose={() => setSelectedStudent(null)} />
          </aside>
        </div>
        <footer>College Student Management System <span>•</span> React + Express REST API</footer>
      </main>
    </div>
  );
}
