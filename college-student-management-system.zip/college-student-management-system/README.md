# College Student Management System

Full-stack project using React (Vite) + Node.js + Express REST APIs.

## Requirements
- Node.js (LTS)
- Visual Studio Code

## Project structure
- `student-backend/` — Express REST API on port 5000
- `student-frontend/` — React frontend (Vite)

## 1. Start the backend
Open a terminal in VS Code:

```bash
cd student-backend
npm install
npm start
```

Backend URL: http://localhost:5000  
Health check: http://localhost:5000/api/health  
Students API: http://localhost:5000/api/students

## 2. Start the frontend
Open a **second terminal**:

```bash
cd student-frontend
npm install
npm run dev
```

Open the local URL printed by Vite, usually http://localhost:5173.

## Features
- View students in a table
- Add, update, and delete students
- Search by name or roll number
- Filter by branch
- Student details panel
- Total student count
- Loading and API error messages
- Success feedback after adding/updating
- Delete confirmation

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/students` | List all students |
| GET | `/api/students/:id` | Get one student |
| POST | `/api/students` | Add a student |
| PUT | `/api/students/:id` | Update a student |
| DELETE | `/api/students/:id` | Delete a student |

Note: The sample backend stores data in memory. Data resets to the two sample students whenever the backend server restarts. Replace the in-memory array with a database if persistent storage is required.
