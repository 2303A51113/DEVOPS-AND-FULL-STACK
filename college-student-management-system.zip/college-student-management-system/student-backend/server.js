const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

let students = [
  { id: 1, name: "Rahul", rollNo: "CSE101", branch: "CSE" },
  { id: 2, name: "Priya", rollNo: "CSE102", branch: "CSE" }
];
let nextId = 3;

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "Student API is running" });
});

app.get("/api/students", (req, res) => {
  res.json(students);
});

app.get("/api/students/:id", (req, res) => {
  const student = students.find((item) => item.id === Number(req.params.id));
  if (!student) return res.status(404).json({ message: "Student not found" });
  res.json(student);
});

app.post("/api/students", (req, res) => {
  const { name, rollNo, branch } = req.body || {};
  if (![name, rollNo, branch].every((value) => typeof value === "string" && value.trim())) {
    return res.status(400).json({ message: "Name, roll number, and branch are required." });
  }
  if (students.some((student) => student.rollNo.toLowerCase() === rollNo.trim().toLowerCase())) {
    return res.status(409).json({ message: "That roll number already exists." });
  }
  const student = {
    id: nextId++,
    name: name.trim(),
    rollNo: rollNo.trim().toUpperCase(),
    branch: branch.trim().toUpperCase()
  };
  students.push(student);
  res.status(201).json(student);
});

app.put("/api/students/:id", (req, res) => {
  const id = Number(req.params.id);
  const index = students.findIndex((student) => student.id === id);
  if (index === -1) return res.status(404).json({ message: "Student not found" });

  const { name, rollNo, branch } = req.body || {};
  if (![name, rollNo, branch].every((value) => typeof value === "string" && value.trim())) {
    return res.status(400).json({ message: "Name, roll number, and branch are required." });
  }
  if (students.some((student) => student.id !== id &&
      student.rollNo.toLowerCase() === rollNo.trim().toLowerCase())) {
    return res.status(409).json({ message: "That roll number already exists." });
  }

  students[index] = {
    id,
    name: name.trim(),
    rollNo: rollNo.trim().toUpperCase(),
    branch: branch.trim().toUpperCase()
  };
  res.json(students[index]);
});

app.delete("/api/students/:id", (req, res) => {
  const id = Number(req.params.id);
  const index = students.findIndex((student) => student.id === id);
  if (index === -1) return res.status(404).json({ message: "Student not found" });
  const [deletedStudent] = students.splice(index, 1);
  res.json({ message: "Student deleted successfully", student: deletedStudent });
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: "Internal server error" });
});

app.listen(PORT, () => {
  console.log(`Student backend running at http://localhost:${PORT}`);
});
