import express from 'express';
import cors from 'cors';

export function createApp() {
  const app = express();
  app.use(cors());
  app.use(express.json());

  let products = [
    { id: 1, name: 'Wireless Headphones', price: 1999 },
    { id: 2, name: 'Mechanical Keyboard', price: 2499 },
    { id: 3, name: 'Laptop Stand', price: 899 },
  ];
  let nextId = 4;

  app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));

  app.get('/api/products', (_req, res) => res.json(products));

  app.post('/api/products', (req, res) => {
    const { name, price } = req.body ?? {};
    if (typeof name !== 'string' || !name.trim() || !Number.isFinite(Number(price)) || Number(price) <= 0) {
      return res.status(400).json({ error: 'A non-empty name and a price greater than zero are required.' });
    }
    const product = { id: nextId++, name: name.trim(), price: Number(price) };
    products.push(product);
    return res.status(201).json(product);
  });

  app.put('/api/products/:id', (req, res) => {
    const id = Number(req.params.id);
    const index = products.findIndex((product) => product.id === id);
    if (index === -1) return res.status(404).json({ error: 'Product not found.' });

    const current = products[index];
    const name = req.body?.name === undefined ? current.name : req.body.name;
    const price = req.body?.price === undefined ? current.price : Number(req.body.price);
    if (typeof name !== 'string' || !name.trim() || !Number.isFinite(price) || price <= 0) {
      return res.status(400).json({ error: 'A non-empty name and a price greater than zero are required.' });
    }

    products[index] = { ...current, name: name.trim(), price };
    return res.json(products[index]);
  });

  app.delete('/api/products/:id', (req, res) => {
    const id = Number(req.params.id);
    const existing = products.some((product) => product.id === id);
    if (!existing) return res.status(404).json({ error: 'Product not found.' });
    products = products.filter((product) => product.id !== id);
    return res.status(204).end();
  });

  return app;
}
