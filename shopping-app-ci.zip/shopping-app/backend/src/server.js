import { createApp } from './app.js';

const port = process.env.PORT || 5000;
createApp().listen(port, () => {
  console.log(`Shopping API listening on http://localhost:${port}`);
});
