import { after, before, describe, it } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import { createApp } from '../src/app.js';

let app;

before(() => {
  app = createApp();
});

describe('Products API', () => {
  it('GET returns the product list', async () => {
    const response = await request(app).get('/api/products').expect(200);
    assert.ok(Array.isArray(response.body));
    assert.ok(response.body.some((product) => product.name === 'Wireless Headphones'));
  });

  it('POST creates a product', async () => {
    const response = await request(app)
      .post('/api/products')
      .send({ name: 'USB-C Hub', price: 799 })
      .expect(201);
    assert.equal(response.body.name, 'USB-C Hub');
    assert.equal(response.body.price, 799);
    assert.ok(response.body.id);
  });

  it('POST rejects invalid product data', async () => {
    await request(app).post('/api/products').send({ name: '', price: -1 }).expect(400);
  });

  it('PUT updates a product', async () => {
    const created = await request(app).post('/api/products').send({ name: 'Old Name', price: 100 }).expect(201);
    const response = await request(app)
      .put(`/api/products/${created.body.id}`)
      .send({ name: 'New Name', price: 150 })
      .expect(200);
    assert.equal(response.body.name, 'New Name');
    assert.equal(response.body.price, 150);
  });

  it('PUT returns 404 for a missing product', async () => {
    await request(app).put('/api/products/999999').send({ name: 'Missing', price: 10 }).expect(404);
  });

  it('DELETE removes a product', async () => {
    const created = await request(app).post('/api/products').send({ name: 'Delete Me', price: 50 }).expect(201);
    await request(app).delete(`/api/products/${created.body.id}`).expect(204);
    await request(app).get('/api/products').expect(200).then((response) => {
      assert.equal(response.body.some((product) => product.id === created.body.id), false);
    });
  });

  it('DELETE returns 404 for a missing product', async () => {
    await request(app).delete('/api/products/999999').expect(404);
  });
});

after(() => {});
