# Shopping Application CI

A starter full-stack online shopping application with a React frontend, Express backend, automated tests, ESLint, coverage, and GitHub Actions CI.

## Features
- Product listing and search
- Add, update, and delete products
- Shopping cart (add/remove items and quantity display)
- REST API: `GET/POST /api/products`, `PUT/DELETE /api/products/:id`
- Frontend and backend tests
- ESLint, test coverage, frontend build
- GitHub Actions workflow with separate frontend/backend jobs and dependency caching

## Requirements
- Node.js 20+
- npm

## Run locally

Open two terminals.

### Backend
```bash
cd backend
npm install
npm test
npm run lint
npm run dev
```
Backend runs at `http://localhost:5000`.

### Frontend
```bash
cd frontend
npm install
npm test
npm run lint
npm run build
npm run dev
```
Vite prints the local frontend URL (usually `http://localhost:5173`).

## API
- `GET /api/products` — list products
- `POST /api/products` — create product (`{"name":"Keyboard","price":49.99}`)
- `PUT /api/products/:id` — update product fields
- `DELETE /api/products/:id` — delete product

The backend uses an in-memory store for a simple assignment/demo. Data resets when the backend restarts.

## GitHub Actions
The workflow is `.github/workflows/ci.yml`. It runs on pushes and pull requests targeting `main`, and uses path filters so frontend changes run frontend checks and backend changes run backend checks. Changes to workflow files or the root README run both jobs.

## Branch protection
In GitHub: **Settings → Branches → Add branch protection rule** (or repository rulesets), target `main`, enable **Require a pull request before merging** and **Require status checks to pass before merging**. After the first workflow run, select the frontend and backend check jobs as required checks.

## Intentionally testing a failure
Temporarily change an expected value in a test (for example, change the expected product name in `frontend/src/App.test.jsx`), commit and push. The related CI job should fail. Restore the correct expectation, commit, and push again to see CI pass.

## CI status badge
After pushing to GitHub, replace `YOUR-USERNAME/YOUR-REPO` in the badge below:
```markdown
![Shopping Application CI](https://github.com/YOUR-USERNAME/YOUR-REPO/actions/workflows/ci.yml/badge.svg)
```
