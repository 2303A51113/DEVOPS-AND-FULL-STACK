import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    setupFiles: './src/testSetup.js',
    coverage: {
      reporter: ['text', 'lcov'],
      include: ['src/App.jsx'],
      thresholds: { lines: 70, functions: 70, branches: 60, statements: 70 },
    },
  },
});
