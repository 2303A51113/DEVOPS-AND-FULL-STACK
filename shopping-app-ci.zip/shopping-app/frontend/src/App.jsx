import { useMemo, useState } from 'react';

const initialProducts = [
  { id: 1, name: 'Wireless Headphones', price: 1999 },
  { id: 2, name: 'Mechanical Keyboard', price: 2499 },
  { id: 3, name: 'Laptop Stand', price: 899 },
];

export default function App() {
  const [products, setProducts] = useState(initialProducts);
  const [search, setSearch] = useState('');
  const [cart, setCart] = useState([]);
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [editingId, setEditingId] = useState(null);

  const filteredProducts = useMemo(
    () => products.filter((product) => product.name.toLowerCase().includes(search.toLowerCase())),
    [products, search],
  );

  function saveProduct(event) {
    event.preventDefault();
    const trimmedName = name.trim();
    const numericPrice = Number(price);
    if (!trimmedName || !Number.isFinite(numericPrice) || numericPrice <= 0) return;

    if (editingId !== null) {
      setProducts((current) => current.map((product) => (
        product.id === editingId ? { ...product, name: trimmedName, price: numericPrice } : product
      )));
      setEditingId(null);
    } else {
      setProducts((current) => [...current, { id: Date.now(), name: trimmedName, price: numericPrice }]);
    }
    setName('');
    setPrice('');
  }

  function editProduct(product) {
    setEditingId(product.id);
    setName(product.name);
    setPrice(String(product.price));
  }

  function deleteProduct(id) {
    setProducts((current) => current.filter((product) => product.id !== id));
    setCart((current) => current.filter((item) => item.id !== id));
    if (editingId === id) {
      setEditingId(null);
      setName('');
      setPrice('');
    }
  }

  function addToCart(product) {
    setCart((current) => {
      const existing = current.find((item) => item.id === product.id);
      return existing
        ? current.map((item) => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item)
        : [...current, { ...product, quantity: 1 }];
    });
  }

  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
  const cartTotal = cart.reduce((total, item) => total + item.price * item.quantity, 0);

  return (
    <main className="container">
      <header className="hero">
        <p className="eyebrow">EVERYDAY ESSENTIALS</p>
        <h1>Shopping Application</h1>
        <p>Find your next favourite thing.</p>
      </header>

      <section className="panel" aria-labelledby="products-heading">
        <div className="section-heading">
          <h2 id="products-heading">Products</h2>
          <span className="pill">{filteredProducts.length} items</span>
        </div>
        <label htmlFor="product-search">Search products</label>
        <input id="product-search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search by product name..." />
        <div className="product-grid">
          {filteredProducts.map((product) => (
            <article className="product-card" key={product.id}>
              <div className="product-icon" aria-hidden="true">▣</div>
              <h3>{product.name}</h3>
              <p className="price">₹{product.price.toLocaleString('en-IN')}</p>
              <div className="actions">
                <button type="button" onClick={() => addToCart(product)}>Add to cart</button>
                <button type="button" className="secondary" onClick={() => editProduct(product)}>Edit</button>
                <button type="button" className="danger" onClick={() => deleteProduct(product.id)}>Delete</button>
              </div>
            </article>
          ))}
          {filteredProducts.length === 0 && <p role="status">No products found.</p>}
        </div>
      </section>

      <section className="panel" aria-labelledby="manage-heading">
        <h2 id="manage-heading">{editingId === null ? 'Add a product' : 'Update product'}</h2>
        <form onSubmit={saveProduct} className="product-form">
          <label htmlFor="product-name">Product name</label>
          <input id="product-name" value={name} onChange={(event) => setName(event.target.value)} required placeholder="e.g. USB-C Hub" />
          <label htmlFor="product-price">Price (₹)</label>
          <input id="product-price" type="number" min="0.01" step="0.01" value={price} onChange={(event) => setPrice(event.target.value)} required placeholder="e.g. 799" />
          <div className="actions">
            <button type="submit">{editingId === null ? 'Add product' : 'Save changes'}</button>
            {editingId !== null && <button type="button" className="secondary" onClick={() => { setEditingId(null); setName(''); setPrice(''); }}>Cancel edit</button>}
          </div>
        </form>
      </section>

      <section className="panel" aria-labelledby="cart-heading">
        <div className="section-heading">
          <h2 id="cart-heading">Shopping cart</h2>
          <span className="pill" data-testid="cart-count">{cartCount} items</span>
        </div>
        {cart.length === 0 ? <p>Your cart is empty.</p> : (
          <>
            <ul className="cart-list">
              {cart.map((item) => (
                <li key={item.id}>
                  <span>{item.name} × {item.quantity}</span>
                  <span>₹{(item.price * item.quantity).toLocaleString('en-IN')}</span>
                  <button type="button" className="secondary" onClick={() => setCart((current) => current.filter((cartItem) => cartItem.id !== item.id))}>Remove</button>
                </li>
              ))}
            </ul>
            <p className="cart-total">Total: ₹{cartTotal.toLocaleString('en-IN')}</p>
          </>
        )}
      </section>
      <footer>Demo project • React + Vite • CI with GitHub Actions</footer>
    </main>
  );
}
