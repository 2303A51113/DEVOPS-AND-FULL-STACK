import { describe, expect, it } from 'vitest';
import { fireEvent, render, screen, within } from '@testing-library/react';
import App from './App.jsx';

describe('Shopping application', () => {
  it('renders products', () => {
    render(<App />);
    expect(screen.getByRole('heading', { name: 'Wireless Headphones' })).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: 'Mechanical Keyboard' })).toBeInTheDocument();
  });

  it('filters products by search text', () => {
    render(<App />);
    fireEvent.change(screen.getByLabelText('Search products'), { target: { value: 'keyboard' } });
    expect(screen.getByRole('heading', { name: 'Mechanical Keyboard' })).toBeInTheDocument();
    expect(screen.queryByRole('heading', { name: 'Wireless Headphones' })).not.toBeInTheDocument();
  });

  it('adds products to the cart and updates quantity and total', () => {
    render(<App />);
    const cards = screen.getAllByRole('article');
    fireEvent.click(within(cards[0]).getByRole('button', { name: 'Add to cart' }));
    fireEvent.click(within(cards[0]).getByRole('button', { name: 'Add to cart' }));
    expect(screen.getByTestId('cart-count')).toHaveTextContent('2 items');
    expect(screen.getByText('Total: ₹3,998')).toBeInTheDocument();
  });

  it('adds, updates, and deletes products', () => {
    render(<App />);
    fireEvent.change(screen.getByLabelText('Product name'), { target: { value: 'USB-C Hub' } });
    fireEvent.change(screen.getByLabelText('Price (₹)'), { target: { value: '799' } });
    fireEvent.click(screen.getByRole('button', { name: 'Add product' }));
    expect(screen.getByRole('heading', { name: 'USB-C Hub' })).toBeInTheDocument();

    const card = screen.getAllByRole('article').find((article) => within(article).queryByRole('heading', { name: 'USB-C Hub' }));
    fireEvent.click(within(card).getByRole('button', { name: 'Edit' }));
    fireEvent.change(screen.getByLabelText('Product name'), { target: { value: 'USB-C Hub Pro' } });
    fireEvent.click(screen.getByRole('button', { name: 'Save changes' }));
    expect(screen.getByRole('heading', { name: 'USB-C Hub Pro' })).toBeInTheDocument();

    const updatedCard = screen.getAllByRole('article').find((article) => within(article).queryByRole('heading', { name: 'USB-C Hub Pro' }));
    fireEvent.click(within(updatedCard).getByRole('button', { name: 'Delete' }));
    expect(screen.queryByRole('heading', { name: 'USB-C Hub Pro' })).not.toBeInTheDocument();
  });
});
