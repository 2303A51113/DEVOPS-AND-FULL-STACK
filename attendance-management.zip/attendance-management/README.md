# College Student Attendance Dashboard

A React-based College Attendance Management System created for DevOps and Fullstack Assignment 8.1.1.

## Features

- React functional components
- Props between parent and child components
- `useState()` for attendance state
- Present / Absent buttons
- Dynamic attendance percentage
- Eligible / Not Eligible status at 75%
- Present and absent student summary
- Search students
- Reset attendance
- Low-attendance highlighting
- Responsive dashboard UI

## Project structure

```text
attendance-management/
├── public/
├── src/
│   ├── components/
│   │   ├── Attendance.jsx
│   │   ├── Header.jsx
│   │   ├── StudentCard.jsx
│   │   ├── StudentList.jsx
│   │   └── Summary.jsx
│   ├── App.jsx
│   ├── main.jsx
│   └── styles.css
├── .gitignore
├── index.html
├── package.json
├── vite.config.js
└── README.md
```

## Run in VS Code

Open the project folder in VS Code, then open Terminal:

```bash
npm install
npm run dev
```

Open the local URL shown by Vite, normally:

```text
http://localhost:5173
```

## Build

```bash
npm run build
```

## GitHub

```bash
git init
git add .
git commit -m "Initial commit - attendance management system"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/attendance-management.git
git push -u origin main
```
