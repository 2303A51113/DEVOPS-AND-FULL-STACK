function Summary({
  totalStudents,
  presentStudents,
  absentStudents,
  averageAttendance
}) {
  const cards = [
    ["Total Students", totalStudents, "Students in dashboard"],
    ["Present", presentStudents, "Attendance ≥ 75%"],
    ["Absent", absentStudents, "Attendance < 75%"],
    ["Average", `${averageAttendance}%`, "Class average"]
  ];

  return (
    <section className="summary-grid">
      {cards.map(([label, value, note]) => (
        <div className="summary-card" key={label}>
          <span>{label}</span>
          <strong>{value}</strong>
          <small>{note}</small>
        </div>
      ))}
    </section>
  );
}

export default Summary;