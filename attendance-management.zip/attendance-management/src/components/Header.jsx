function Header() {
  return (
    <header className="header">
      <div className="header-inner">
        <div className="brand-mark">CA</div>
        <div>
          <strong>College Attendance</strong>
          <span>Management Dashboard</span>
        </div>
      </div>
    </header>
  );
}

export default Header;