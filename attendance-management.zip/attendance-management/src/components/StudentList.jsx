import StudentCard from "./StudentCard";

function StudentList({ students, onAttendanceChange }) {
  if (students.length === 0) {
    return (
      <div className="empty-state">
        <h3>No students found</h3>
        <p>Try a different name, roll number or branch.</p>
      </div>
    );
  }

  return (
    <div className="student-grid">
      {students.map((student) => (
        <StudentCard
          key={student.id}
          student={student}
          onAttendanceChange={onAttendanceChange}
        />
      ))}
    </div>
  );
}

export default StudentList;