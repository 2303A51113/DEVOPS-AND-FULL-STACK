function Attendance({
  studentName,
  rollNumber,
  attendance,
  onAttendanceChange,
  studentId
}) {
  return (
    <div className="attendance-actions">
      <div>
        <small>Update attendance</small>
        <p>{studentName} · {rollNumber}</p>
      </div>
      <div className="action-buttons">
        <button
          className="present-btn"
          onClick={() => onAttendanceChange(studentId, "present")}
          aria-label={`Mark ${studentName} present`}
        >
          Present
        </button>
        <button
          className="absent-btn"
          onClick={() => onAttendanceChange(studentId, "absent")}
          aria-label={`Mark ${studentName} absent`}
        >
          Absent
        </button>
      </div>
      <span className="mini-value">{attendance}%</span>
    </div>
  );
}

export default Attendance;