import Attendance from "./Attendance";

function StudentCard({ student, onAttendanceChange }) {
  const eligible = student.attendance >= 75;

  return (
    <article className={`student-card ${eligible ? "" : "low-attendance"}`}>
      <div className="student-top">
        <div className="avatar">{student.name.charAt(0)}</div>
        <div className="student-info">
          <h3>{student.name}</h3>
          <p>{student.rollNumber} · {student.branch}</p>
        </div>
        <span className={`status ${eligible ? "eligible" : "not-eligible"}`}>
          {eligible ? "Eligible" : "Not Eligible"}
        </span>
      </div>

      <div className="attendance-panel">
        <div className="percentage">
          <strong>{student.attendance}%</strong>
          <span>Attendance</span>
        </div>
        <div className="progress-track">
          <div
            className={`progress-fill ${eligible ? "" : "danger"}`}
            style={{ width: `${student.attendance}%` }}
          />
        </div>
        <p className="attendance-detail">
          {student.present} present out of {student.total} classes
        </p>
      </div>

      <Attendance
        studentName={student.name}
        rollNumber={student.rollNumber}
        attendance={student.attendance}
        onAttendanceChange={onAttendanceChange}
        studentId={student.id}
      />
    </article>
  );
}

export default StudentCard;