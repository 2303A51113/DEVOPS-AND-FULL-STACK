import { useMemo, useState } from "react";
import Header from "./components/Header";
import StudentList from "./components/StudentList";
import Summary from "./components/Summary";

const initialStudents = [
  { id: 1, name: "Aarav Kumar", rollNumber: "23CS001", branch: "CSE", attendance: 88, present: 44, total: 50 },
  { id: 2, name: "Ananya Reddy", rollNumber: "23CS002", branch: "CSE", attendance: 76, present: 38, total: 50 },
  { id: 3, name: "Rahul Sharma", rollNumber: "23AI003", branch: "AI & ML", attendance: 68, present: 34, total: 50 },
  { id: 4, name: "Sneha Patel", rollNumber: "23DS004", branch: "Data Science", attendance: 92, present: 46, total: 50 },
  { id: 5, name: "Vikram Singh", rollNumber: "23CS005", branch: "CSE", attendance: 72, present: 36, total: 50 },
  { id: 6, name: "Meera Nair", rollNumber: "23EC006", branch: "ECE", attendance: 81, present: 40, total: 49 }
];

function App() {
  const [students, setStudents] = useState(initialStudents);
  const [search, setSearch] = useState("");

  const updateAttendance = (id, status) => {
    setStudents((current) =>
      current.map((student) => {
        if (student.id !== id) return student;

        const nextPresent = status === "present"
          ? Math.min(student.present + 1, student.total + 1)
          : student.present;

        const nextTotal = student.total + 1;
        const nextAttendance = Math.round((nextPresent / nextTotal) * 100);

        return {
          ...student,
          present: nextPresent,
          total: nextTotal,
          attendance: nextAttendance
        };
      })
    );
  };

  const resetAttendance = () => {
    setStudents(initialStudents);
  };

  const filteredStudents = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return students;

    return students.filter((student) =>
      [student.name, student.rollNumber, student.branch]
        .some((value) => value.toLowerCase().includes(query))
    );
  }, [students, search]);

  const presentStudents = students.filter((student) => student.attendance >= 75).length;
  const absentStudents = students.length - presentStudents;
  const averageAttendance = students.length
    ? Math.round(students.reduce((sum, student) => sum + student.attendance, 0) / students.length)
    : 0;

  return (
    <div className="app-shell">
      <Header />
      <main className="container">
        <section className="hero">
          <div>
            <p className="eyebrow">Faculty Dashboard</p>
            <h1>Student Attendance Management System</h1>
            <p className="subtitle">
              Manage student attendance using React state, props, reusable components and conditional rendering.
            </p>
          </div>
          <button className="reset-btn" onClick={resetAttendance}>Reset Attendance</button>
        </section>

        <Summary
          totalStudents={students.length}
          presentStudents={presentStudents}
          absentStudents={absentStudents}
          averageAttendance={averageAttendance}
        />

        <section className="toolbar">
          <div>
            <h2>Student List</h2>
            <p>Mark each student Present or Absent.</p>
          </div>
          <label className="search-box">
            <span>Search</span>
            <input
              type="search"
              placeholder="Name, roll number or branch..."
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
          </label>
        </section>

        <StudentList
          students={filteredStudents}
          onAttendanceChange={updateAttendance}
        />
      </main>
    </div>
  );
}

export default App;